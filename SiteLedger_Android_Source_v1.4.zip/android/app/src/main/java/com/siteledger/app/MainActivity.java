package com.siteledger.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.speech.RecognizerIntent;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.activity.OnBackPressedCallback;

import com.getcapacitor.BridgeActivity;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends BridgeActivity {
    private static final int CREATE_DOCUMENT_REQUEST = 7313;
    private static final int SPEECH_RECOGNITION_REQUEST = 7314;

    private WebView appWebView;
    private Uri pendingSourceUri;
    private String pendingFileName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        appWebView = getBridge().getWebView();
        WebSettings settings = appWebView.getSettings();
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        appWebView.clearCache(true);
        appWebView.addJavascriptInterface(new SiteLedgerNativeBridge(), "SiteLedgerNative");

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (appWebView == null) {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                    return;
                }
                appWebView.evaluateJavascript(
                    "window.siteLedgerHandleBack ? window.siteLedgerHandleBack() : false",
                    value -> {
                        if (!"true".equals(value)) {
                            setEnabled(false);
                            getOnBackPressedDispatcher().onBackPressed();
                        }
                    }
                );
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (appWebView != null) {
            appWebView.post(() -> appWebView.evaluateJavascript(
                "window.siteLedgerNativeResume && window.siteLedgerNativeResume();",
                null
            ));
        }
    }

    private final class SiteLedgerNativeBridge {
        @JavascriptInterface
        public void printPage(String title) {
            runOnUiThread(() -> {
                String jobName = title == null || title.trim().isEmpty() ? "SiteLedger" : title.trim();
                PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                PrintDocumentAdapter adapter = appWebView.createPrintDocumentAdapter(jobName);
                printManager.print(jobName, adapter, new PrintAttributes.Builder().build());
            });
        }

        @JavascriptInterface
        public void saveFileFromUri(String sourceUri, String fileName, String mimeType) {
            runOnUiThread(() -> {
                if (pendingSourceUri != null) {
                    notifySaveResult(false, fileName);
                    return;
                }
                try {
                    pendingSourceUri = Uri.parse(sourceUri);
                    pendingFileName = fileName == null || fileName.trim().isEmpty() ? "siteledger-export" : fileName.trim();
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(mimeType == null || mimeType.trim().isEmpty() ? "application/octet-stream" : mimeType);
                    intent.putExtra(Intent.EXTRA_TITLE, pendingFileName);
                    startActivityForResult(intent, CREATE_DOCUMENT_REQUEST);
                } catch (Exception error) {
                    String failedName = pendingFileName;
                    cleanupPendingSource();
                    notifySaveResult(false, failedName);
                }
            });
        }

        @JavascriptInterface
        public void startSpeechRecognition(String languageTag) {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    String language = languageTag == null || languageTag.trim().isEmpty()
                        ? Locale.getDefault().toLanguageTag()
                        : languageTag.trim();
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
                    intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                    startActivityForResult(intent, SPEECH_RECOGNITION_REQUEST);
                } catch (ActivityNotFoundException error) {
                    notifySpeechResult(false, "");
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CREATE_DOCUMENT_REQUEST) {
            boolean success = false;
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null && pendingSourceUri != null) {
                Uri destination = data.getData();
                try (InputStream input = openSourceStream(pendingSourceUri);
                     OutputStream output = getContentResolver().openOutputStream(destination, "w")) {
                    if (input != null && output != null) {
                        byte[] buffer = new byte[8192];
                        int count;
                        while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                        output.flush();
                        success = true;
                    }
                } catch (Exception ignored) {
                    success = false;
                }
            }
            String completedFileName = pendingFileName;
            cleanupPendingSource();
            notifySaveResult(success, completedFileName);
            return;
        }

        if (requestCode == SPEECH_RECOGNITION_REQUEST) {
            String text = "";
            boolean success = false;
            if (resultCode == Activity.RESULT_OK && data != null) {
                ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (results != null && !results.isEmpty()) {
                    text = results.get(0);
                    success = text != null && !text.trim().isEmpty();
                }
            }
            notifySpeechResult(success, text);
            return;
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    private InputStream openSourceStream(Uri source) throws Exception {
        if ("file".equalsIgnoreCase(source.getScheme())) return new FileInputStream(new File(source.getPath()));
        return getContentResolver().openInputStream(source);
    }

    private void cleanupPendingSource() {
        if (pendingSourceUri != null && "file".equalsIgnoreCase(pendingSourceUri.getScheme())) {
            try {
                File sourceFile = new File(pendingSourceUri.getPath());
                if (sourceFile.exists()) sourceFile.delete();
            } catch (Exception ignored) {}
        }
        pendingSourceUri = null;
        pendingFileName = null;
    }

    private void notifySaveResult(boolean success, String fileName) {
        String safeName = fileName == null ? "" : fileName;
        String script = "window.siteLedgerNativeSaveResult && window.siteLedgerNativeSaveResult(" +
            (success ? "true" : "false") + "," + JSONObject.quote(safeName) + ");";
        if (appWebView != null) appWebView.post(() -> appWebView.evaluateJavascript(script, null));
    }

    private void notifySpeechResult(boolean success, String text) {
        String safeText = text == null ? "" : text;
        String script = "window.siteLedgerNativeSpeechResult && window.siteLedgerNativeSpeechResult(" +
            (success ? "true" : "false") + "," + JSONObject.quote(safeText) + ");";
        if (appWebView != null) appWebView.post(() -> appWebView.evaluateJavascript(script, null));
    }
}
