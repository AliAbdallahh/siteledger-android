# SiteLedger Android conversion audit — v1.4

## Fixed
- Hardware Back navigation.
- Print-mode cleanup after Android Print Manager.
- Save-As concurrency and temporary-cache cleanup.
- Native Android speech recognition.
- Attachment limits: 20 MB/file and 50 MB/movement.
- Portable backup attachment limit: 100 MB.
- Atomic attachment restore.
- Visible localStorage failure warning.
- CSP/frame blocking around the native bridge.
- Gesture-navigation safe-area padding.
- Removed INTERNET permission from the offline build.
- Unsupported-WebView fallback page.
- ZIP-aware APK and AAB workflows.

## Still required before production
- Move operational data from WebView storage to a native/cloud database for multi-user use.
- Encrypt portable backups containing sensitive documents.
- Replace JavascriptInterface with a formal Capacitor plugin or origin-scoped WebMessageListener before any remote content is allowed.
- Run Android UI tests on API 24, 29, 35 and 36.
