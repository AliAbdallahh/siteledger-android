# SiteLedger Android

Android application project built with Capacitor 8.

- App ID: `com.siteledger.app`
- App name: `SiteLedger`
- Minimum Android: API 24 / Android 7
- Target SDK: API 36
- Version code: 2
- Version name: 1.1

## Included Android integrations

- Offline packaged application; it does not depend on a hosted website
- Native Android file saving and sharing for Excel, CSV, backups and evidence
- Android image/document picker support
- Full project backup and restore
- Arabic and English interface
- WebView stale-cache prevention between app updates
- Keyboard resizing for mobile forms
- Android cloud/device backup disabled; transfer is performed only through SiteLedger backup files

## Build a debug APK with GitHub

The repository includes `.github/workflows/build-debug-apk.yml`. Upload this project to GitHub and run **Build Android Debug APK** from the Actions tab. GitHub will provide `app-debug.apk` as a downloadable artifact.

See `docs/GITHUB_BUILD_FROM_PHONE.md`.

## Open in Android Studio

1. Install Node.js 22+, Java 21 and current Android Studio.
2. Run `npm ci` in this folder.
3. Run `npx cap sync android`.
4. Open the `android` directory in Android Studio.

## Local build commands

- Debug APK: `npm run build:apk`
- Release AAB: `npm run build:aab`

The Play Store AAB must be signed using a private upload keystore. The included release GitHub workflow reads signing credentials from repository secrets.


## v1.1 fixes

- The top `+` button now opens **Add Project** instead of attempting browser/PWA installation.
- Removed the misleading “installation is not available in this browser” path from Android.
- New projects start with an editable `General works` / `أعمال عامة` work area.
- Project creation falls back to that work area if the field is left empty.
- The project-name field receives focus when the dialog opens.


## v1.2 cache-origin fix

- Changed Capacitor's internal hostname to `siteledger-v12.local`.
- This bypasses every service worker/cache created by older localhost builds.
- Added visible `v1.2` text in the app header.
- Removed the old installation-unavailable text completely.
- Added legacy service-worker/cache cleanup for native Android.
- Added a second direct click listener to the New Project `+` button.
- Android versionCode is 3 and versionName is 1.2.


## v1.3 fixes

- Android-native Print Manager for project reports, reconciliation and purchase requests.
- Export buttons now open Android's Save As picker instead of the share menu.
- Fixed Add Material: the missing submit-button type caused the dialog JavaScript to fail.
- Added mobile movement cards and visible Edit/Delete buttons on recent entries.
- Corrected generic Edit labels that previously appeared as Rename.
- Added separate English and Arabic material names throughout the app.
- Updated Excel and CSV templates/import/export for both material-name languages.
- Existing materials migrate automatically; their old name remains available.
- Android versionCode: 4; versionName: 1.3.


## v1.4 Android hardening
Hardware Back, print cleanup, Save-As locking/cleanup, native speech, attachment memory limits, atomic restore, storage failure alerts, CSP, safe areas, offline manifest, and ZIP-aware AAB workflow. Android versionCode 5 / versionName 1.4.
