# SiteLedger Android

Android application project built with Capacitor 8.

- App ID: `com.siteledger.app`
- App name: `SiteLedger`
- Minimum Android: API 24 / Android 7
- Target SDK: API 36
- Version code: 1
- Version name: 1.0

## Included Android integrations

- Offline packaged application; it does not depend on a hosted website
- Native Android file saving and sharing for Excel, CSV, backups and evidence
- Android image/document picker support
- Full project backup and restore
- Arabic and English interface
- WebView stale-cache prevention between app updates
- Keyboard resizing for mobile forms
- Android cloud/device backup disabled; transfer is performed only through SiteLedger backup files

## Build a debug APK with GitHub

The repository includes `.github/workflows/build-debug-apk.yml`. Upload this project to GitHub and run **Build Android Debug APK** from the Actions tab. GitHub will provide `app-debug.apk` as a downloadable artifact.

See `docs/GITHUB_BUILD_FROM_PHONE.md`.

## Open in Android Studio

1. Install Node.js 22+, Java 21 and current Android Studio.
2. Run `npm ci` in this folder.
3. Run `npx cap sync android`.
4. Open the `android` directory in Android Studio.

## Local build commands

- Debug APK: `npm run build:apk`
- Release AAB: `npm run build:aab`

The Play Store AAB must be signed using a private upload keystore. The included release GitHub workflow reads signing credentials from repository secrets.
