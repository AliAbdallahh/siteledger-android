# Build SiteLedger from a phone with GitHub Actions

## First debug APK

1. Create a private GitHub repository named `siteledger-android`.
2. Upload the contents of this project, preserving the folders.
3. Open the repository's **Actions** tab.
4. Select **Build Android Debug APK**.
5. Tap **Run workflow**.
6. After the workflow finishes, open the run and download the artifact named `SiteLedger-debug-apk`.
7. Extract the downloaded artifact ZIP and install `app-debug.apk` on Android.

Android may ask you to allow installation from your browser or file manager.

## Signed AAB for Google Play

The Play Store build needs an upload keystore. Add these repository secrets:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Then run **Build Signed Play Store AAB** from the Actions tab. Download the `SiteLedger-release-aab` artifact and upload `app-release.aab` to Google Play Console.

Never commit the keystore or passwords to GitHub.
