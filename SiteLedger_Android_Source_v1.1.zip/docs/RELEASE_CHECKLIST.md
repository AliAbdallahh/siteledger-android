# SiteLedger Android release checklist

- [ ] Install and test the debug APK on at least two Android devices.
- [ ] Test creating a project and automatic country/currency selection.
- [ ] Test Excel import and export.
- [ ] Test photos and PDF evidence.
- [ ] Test full backup and restore.
- [ ] Test Arabic and English layouts.
- [ ] Confirm app version code and version name.
- [ ] Create and securely back up the upload keystore.
- [ ] Build the signed AAB.
- [ ] Prepare privacy policy and Data Safety answers.
- [ ] Prepare phone screenshots and feature graphic.
- [ ] Complete the required Play closed test for the account, if applicable.
